void Riemersma(uint8_t* image,int width, int height, int shades, int samples = 1);
