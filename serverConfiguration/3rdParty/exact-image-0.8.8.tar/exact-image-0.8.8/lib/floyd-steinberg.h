
#ifdef __cplusplus
extern "C" {
#endif

void FloydSteinberg(uint8_t* image, int width, int height, int shades, int samples
#ifdef __cplusplus
  = 1
#endif
);

#ifdef __cplusplus
}
#endif
